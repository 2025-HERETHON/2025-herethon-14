const form = document.getElementById('login-form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginBtn = document.querySelector('.button-group button');
const errorMsg = document.getElementById('error-msg');

// 1. 입력값에 따라 버튼 활성화/비활성화 + 스타일 처리
function checkInputs() {
    // 현재 값 가져오기
    const usernameVal = usernameInput.value.trim();
    const passwordVal = passwordInput.value.trim();

    // filled 클래스 처리 (값이 있으면 유지)
    if (usernameVal !== '') {
        usernameInput.classList.add('filled');
    } else {
        usernameInput.classList.remove('filled');
    }

    if (passwordVal !== '') {
        passwordInput.classList.add('filled');
    } else {
        passwordInput.classList.remove('filled');
    }

    // 버튼 활성화 조건
    if (usernameVal !== '' && passwordVal !== '') {
        loginBtn.disabled = false;
        loginBtn.classList.add('active');
    } else {
        loginBtn.disabled = true;
        loginBtn.classList.remove('active');
    }
}


// 2. 이벤트 리스너 등록
usernameInput.addEventListener('input', checkInputs);
passwordInput.addEventListener('input', checkInputs);
usernameInput.addEventListener('blur', checkInputs);
passwordInput.addEventListener('blur', checkInputs);

// 3. 처음 페이지 로딩 시 버튼 비활성화 초기화
window.addEventListener('DOMContentLoaded', () => {
    loginBtn.disabled = true;
    loginBtn.classList.remove('active');
});

// 4. 로그인 요청 처리
form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    try {
        const response = await fetch('/auth/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({ username, password })
        });

        const result = await response.json();

        if (result.success) {
            window.location.href = 'main.html';
        } else {
            errorMsg.textContent = result.message || '아이디 또는 비밀번호가 일치하지 않습니다.';
            errorMsg.style.display = 'block';
        }
    } catch (error) {
        console.error('서버 오류:', error);
        errorMsg.textContent = '서버 오류가 발생했습니다.';
        errorMsg.style.display = 'block';
    }
});
